let result = document.getElementById("result");

function addValue(value){

    result.value += value;

    try{
        if(result.value !== ""){
            let liveResult = eval(result.value);
            console.log(liveResult);
        }
    }
    catch(error){
    }
}

function clearScreen(){
    result.value = "";
}

function calculate(){

    try{
        result.value = eval(result.value);
    }

    catch(error){
        result.value = "Error";
    }
}